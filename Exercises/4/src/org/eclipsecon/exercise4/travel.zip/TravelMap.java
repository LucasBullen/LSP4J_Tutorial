package org.eclipsecon.exercise1;

public class TravelMap {

}

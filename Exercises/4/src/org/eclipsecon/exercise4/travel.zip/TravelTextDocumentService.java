package org.eclipsecon.exercise1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import org.eclipse.lsp4j.CodeActionParams;
import org.eclipse.lsp4j.CodeLens;
import org.eclipse.lsp4j.CodeLensParams;
import org.eclipse.lsp4j.Command;
import org.eclipse.lsp4j.CompletionItem;
import org.eclipse.lsp4j.CompletionList;
import org.eclipse.lsp4j.Diagnostic;
import org.eclipse.lsp4j.DidChangeTextDocumentParams;
import org.eclipse.lsp4j.DidCloseTextDocumentParams;
import org.eclipse.lsp4j.DidOpenTextDocumentParams;
import org.eclipse.lsp4j.DidSaveTextDocumentParams;
import org.eclipse.lsp4j.DocumentFormattingParams;
import org.eclipse.lsp4j.DocumentHighlight;
import org.eclipse.lsp4j.DocumentOnTypeFormattingParams;
import org.eclipse.lsp4j.DocumentRangeFormattingParams;
import org.eclipse.lsp4j.DocumentSymbolParams;
import org.eclipse.lsp4j.Hover;
import org.eclipse.lsp4j.Location;
import org.eclipse.lsp4j.MarkedString;
import org.eclipse.lsp4j.ReferenceParams;
import org.eclipse.lsp4j.RenameParams;
import org.eclipse.lsp4j.SignatureHelp;
import org.eclipse.lsp4j.SymbolInformation;
import org.eclipse.lsp4j.TextDocumentPositionParams;
import org.eclipse.lsp4j.TextEdit;
import org.eclipse.lsp4j.WorkspaceEdit;
import org.eclipse.lsp4j.jsonrpc.messages.Either;
import org.eclipse.lsp4j.services.TextDocumentService;
import org.eclipsecon.exercise1.TravelDocumentModel.City;
import org.eclipsecon.exercise1.TravelDocumentModel.Trip;

public class TravelTextDocumentService implements TextDocumentService{
	
	private final Map<String, TravelDocumentModel> docs = Collections.synchronizedMap(new HashMap<>());
	private List<String> completionStrings;
	private final TravelLanguageServer travelLanguageServer;
	
	public TravelTextDocumentService(TravelLanguageServer travelLanguageServer) {
		this.travelLanguageServer = travelLanguageServer;
		completionStrings = new ArrayList<String>();
		completionStrings.add("Ottawa");
		completionStrings.add("Berlin");
		completionStrings.add("Paris");
		completionStrings.add("Prague");
		completionStrings.add("Washington");
	}

	@Override
	public CompletableFuture<Either<List<CompletionItem>, CompletionList>> completion(
			TextDocumentPositionParams position) {
		TravelDocumentModel doc = docs.get(position.getTextDocument().getUri());
		String line = doc.getTextLine(position.getPosition().getLine());

		if(line != null && position.getPosition().getCharacter() > 0
				&& line.charAt(position.getPosition().getCharacter()-1) != '>'){
			CompletionItem item = new CompletionItem(">");
			return CompletableFuture.completedFuture(Either.forLeft(Collections.singletonList(item)));
		}

		return CompletableFuture.supplyAsync(() -> Either.forLeft(completionStrings.stream()
				.map(capital -> {
					CompletionItem item = new CompletionItem();
					item.setLabel(capital);
					item.setInsertText(capital);
					return item;
				}).collect(Collectors.toList())));
	}

	@Override
	public CompletableFuture<CompletionItem> resolveCompletionItem(CompletionItem unresolved) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<Hover> hover(TextDocumentPositionParams position) {
		return CompletableFuture.supplyAsync(() -> {
			TravelDocumentModel doc = docs.get(position.getTextDocument().getUri());
			Hover res = new Hover();
			Trip trip = doc.getTripByLine(position.getPosition().getLine());
			if(trip == null) return null;
			List<Either<String, MarkedString>> hoverStrings = new ArrayList<>();

			hoverStrings.add(Either.forLeft("Trip Distance: "+trip.distance));
			City city = trip.getCityByOffset(position.getPosition().getCharacter());
			if(city != null) {
				hoverStrings.add(Either.forLeft(city.name+": "+city.description));
			}
			res.setContents(hoverStrings);
			return res;
		});
	}

	@Override
	public CompletableFuture<SignatureHelp> signatureHelp(TextDocumentPositionParams position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends Location>> definition(TextDocumentPositionParams position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends Location>> references(ReferenceParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends DocumentHighlight>> documentHighlight(TextDocumentPositionParams position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends SymbolInformation>> documentSymbol(DocumentSymbolParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends Command>> codeAction(CodeActionParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends CodeLens>> codeLens(CodeLensParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<CodeLens> resolveCodeLens(CodeLens unresolved) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends TextEdit>> formatting(DocumentFormattingParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends TextEdit>> rangeFormatting(DocumentRangeFormattingParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<List<? extends TextEdit>> onTypeFormatting(DocumentOnTypeFormattingParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CompletableFuture<WorkspaceEdit> rename(RenameParams params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void didOpen(DidOpenTextDocumentParams params) {
		TravelDocumentModel model = new TravelDocumentModel(params.getTextDocument().getText());
		this.docs.put(params.getTextDocument().getUri(),model);
	}

	@Override
	public void didChange(DidChangeTextDocumentParams params) {
		TravelDocumentModel model = new TravelDocumentModel(params.getContentChanges().get(0).getText());
		this.docs.put(params.getTextDocument().getUri(),model);
	}

	private List<Diagnostic> validate(TravelDocumentModel model) {
		List<Diagnostic> res = new ArrayList<>();
		return res;
	}

	@Override
	public void didClose(DidCloseTextDocumentParams params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void didSave(DidSaveTextDocumentParams params) {
		// TODO Auto-generated method stub
		
	}

}

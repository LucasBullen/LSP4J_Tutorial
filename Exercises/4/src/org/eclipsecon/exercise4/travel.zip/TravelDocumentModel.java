package org.eclipsecon.exercise1;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Model for parsing the document
 */
public class TravelDocumentModel {
	public static class City {
		String name;
		String description;
		double lat;
		double lon;
		int population;

		public City(String name, String description, double lat, double lon, int population) {
			this.name = name;
			this.description = description;
			this.lat = lat;
			this.lon = lon;
			this.population = population;
		}
	}

	public class Trip {
		List<City> cities;
		int stops;
		double distance;

		public Trip() {
			this.cities = new ArrayList<>();
			this.stops = 0;
			this.distance = 0;
		}

		public void addCity(City newCity) {
			if(stops > 0) {
				City lastCity = cities.get(stops-1);
				distance += distanceBetweenCities(lastCity, newCity);
			}
			stops++;
			cities.add(newCity);
		}
		
		private double distanceBetweenCities(City a, City b) {
			return Math.sqrt(Math.pow((a.lat-b.lat), 2)+Math.pow((a.lon-b.lon), 2));
		}

		public City getCityByOffset(int offset) {
			for (City city : cities) {
				offset -= city.name.length();
				if(offset <= 0) {
					return city;
				}
				offset--;
				if(offset <= 0) {
					return null;
				}
			}
			return null;
		}
	}

	private final Map<Integer, Trip> trips = new HashMap<>();
	private static final Map<String, City> CITIES = new HashMap<>();
	private final List<String> textLines = new ArrayList<>();
	static {
		URL path = TravelDocumentModel.class.getResource("cities.csv");
		try(Scanner scanner = new Scanner(path.openStream()).useDelimiter("\n")){
			while(scanner.hasNext()) {
				String[] cityInfo = scanner.next().split(",");
				CITIES.put(cityInfo[0], new City(cityInfo[0], cityInfo[1], Double.parseDouble(cityInfo[2]), Double.parseDouble(cityInfo[3]), Integer.parseInt(cityInfo[4])));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public TravelDocumentModel(String text) {
		try (
			Reader r = new StringReader(text);
			BufferedReader reader = new BufferedReader(r);
		) {
			String lineText;
			int lineNumber = 0;
			while ((lineText = reader.readLine()) != null) {
				textLines.add(lineText);
				String[] cityNames = lineText.split(">");
				if(cityNames.length == 0) {
					break;
				}

				Trip trip = new Trip();

				for (String cityName : cityNames) {
					City city = CITIES.get(cityName);
					if(city != null) {
						trip.addCity(city);
					}else {
						break;
					}
				}

				if(trip.stops > 0) {
					trips.put(lineNumber,trip);
				}
				lineNumber++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public City getCity(String cityName) {
		return CITIES.get(cityName);
	}

	public Trip getTripByLine(Integer line) {
		return trips.get(line);
	}

	public String getTextLine(int line) {
		if(textLines.size() > line)
			return textLines.get(line);
		return null;
	}
}

package org.eclipsecon.exercise1;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.eclipse.lsp4j.CompletionOptions;
import org.eclipse.lsp4j.HoverCapabilities;
import org.eclipse.lsp4j.InitializeParams;
import org.eclipse.lsp4j.InitializeResult;
import org.eclipse.lsp4j.ServerCapabilities;
import org.eclipse.lsp4j.services.LanguageClient;
import org.eclipse.lsp4j.services.LanguageServer;
import org.eclipse.lsp4j.services.TextDocumentService;
import org.eclipse.lsp4j.services.WorkspaceService;

public class TravelLanguageServer implements LanguageServer{

	private TextDocumentService textService;
	private WorkspaceService workspaceService;
	LanguageClient client;

	public TravelLanguageServer() {
		textService = new TravelTextDocumentService(this);
		workspaceService = new TravelWorkspaceService();
	}
	
	@Override
	public CompletableFuture<InitializeResult> initialize(InitializeParams params) {
		final InitializeResult result = new InitializeResult(new ServerCapabilities());
		//Add the capabilities of your Language Server below
		
		//Completion
		List<String> triggerCharacters = new ArrayList<>();
		triggerCharacters.add(" ");
		result.getCapabilities().setCompletionProvider(new CompletionOptions(false, triggerCharacters));
		//Others
		result.getCapabilities().setHoverProvider(true);
		
		return CompletableFuture.supplyAsync(() -> result);
	}

	@Override
	public CompletableFuture<Object> shutdown() {
		return CompletableFuture.supplyAsync(() -> Boolean.TRUE);
	}

	@Override
	public void exit() {
		// Nothing done on exit
	}

	@Override
	public TextDocumentService getTextDocumentService() {
		return this.textService;
	}

	@Override
	public WorkspaceService getWorkspaceService() {
		return this.workspaceService;
	}
	

	public void setRemoteProxy(LanguageClient remoteProxy) {
		this.client = remoteProxy;
	}
}
